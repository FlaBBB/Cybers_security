<!DOCTYPE HTML>
<html>
	<head>
		<title> Bypass Auth </title>
	</head>
	<body>
		 <a href="/login.php">Login Here</a> 
		 <a href="/registration.php">Register Here</a>
		 <a href="logout.php">Logout</a>
	</body>
</html>

