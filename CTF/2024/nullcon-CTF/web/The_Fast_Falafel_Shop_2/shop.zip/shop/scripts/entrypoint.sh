#!/bin/bash

bash ./cleaner.sh &

apache2-foreground
