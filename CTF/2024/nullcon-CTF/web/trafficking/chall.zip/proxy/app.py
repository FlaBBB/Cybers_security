import logging
import sys
import slimHTTP

http = slimHTTP.host(slimHTTP.HTTP, port=8080,web_root='./', index='index.html')
@http.configuration
def config(instance):
    return {
        'web_root' : './',
        'index' : 'index.html',
        'vhosts' : {
            'smuggly' : {
                'proxy' : 'smuggly:8080',
            }
        }
    }

@http.route('/admin', vhost='smuggly')
def admin(request):
    return slimHTTP.HTTP_RESPONSE(ret_code=400, payload=b'Forbidden')


while 1:
    for event, *event_data in http.poll():
        pass