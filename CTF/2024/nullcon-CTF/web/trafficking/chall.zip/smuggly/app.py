from aiohttp import web

async def hello(request: web.Request):
    headers = dict(request.headers)
    body = await request.content.read()
    return web.Response(text=f"headers: {headers} body: {body}")

async def admin(request: web.Request):
    flag = open("/tmp/flag").read()
    return web.Response(text=f"{flag}")

app = web.Application()
app.add_routes([web.put('/', hello), web.get('/admin', admin)])
web.run_app(app)