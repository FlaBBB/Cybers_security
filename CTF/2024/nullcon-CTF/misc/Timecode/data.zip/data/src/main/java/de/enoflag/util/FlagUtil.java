package de.enoflag.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FlagUtil {
    public static String getFlag() throws IOException {
        return retrieveFlag(Constants.FLAG_PATH);
    }

    private static String retrieveFlag(String path) throws IOException {
        File file = new File(path);
        String flag = ObfuscationUtil.decrypt(Constants.DEFAULT_FLAG);
        BufferedReader br = new BufferedReader(new FileReader(file));
        flag = br.readLine();
        br.close();
        return flag;
    }
}
