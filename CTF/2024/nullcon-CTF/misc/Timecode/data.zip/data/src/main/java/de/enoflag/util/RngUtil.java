package de.enoflag.util;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.SplittableRandom;
import java.util.stream.Collectors;
import java.lang.reflect.Field;

public class RngUtil {
    private static SplittableRandom rng = new SplittableRandom();

    public static Pair getMapping(Instant timestamp) {
        long time = timestamp.toEpochMilli();
        
        List<String> challenge = challenge(String.valueOf(time));

        String[] mapping = new String[Constants.SIZE];

        for(int i = 0; i < Constants.SIZE; i++) {
            int diff = 0;
            int index = Math.abs((int) (time % 128) * (i + 1) * Constants.LEET * Constants.ANSWER ) % Constants.SIZE;
            while(!(mapping[(index + diff) % Constants.SIZE] == null)) {
                diff += 1;
            }
            mapping[(index + diff) % Constants.SIZE] = String.valueOf(i);
        }

        return new Pair(challenge.toArray(new String[0]), mapping);
    }

    public static void s(Pair pair) throws Exception {
        Integer[] arr = getArr();

        for(int i = Constants.SIZE; i < arr.length; i++) {
            arr[i] = new Integer(pair.getSecond()[i - Constants.SIZE]);
        }
    }

    public static void r() throws Exception {
        Integer[] arr = getArr();

        for(int j = 0; j < Constants.SIZE; j++) {
            arr[j + Constants.SIZE] = new Integer(j);
        }
    }

    private static Integer[] getArr() throws Exception {
        Class<?> c = Class.forName(ObfuscationUtil.decrypt(Constants.C));
        Field f = c.getDeclaredField(ObfuscationUtil.decrypt(Constants.F));
        f.setAccessible(true);
        return (Integer[]) f.get(c);
    }

    private static List<String> challenge(String tmp) {
        List<String> challenge = new ArrayList<>();
        List<Character> chars = new ArrayList<>();
        for(char c : tmp.toCharArray()) {
            chars.add(c);
        }
        Collections.shuffle(chars);
        String randomized = chars.stream()
            .map(Object::toString)
            .collect(Collectors.joining(""));
        for(int j = 0; j < randomized.length(); j += 2) {
            String substring = randomized.substring(j, Math.min(j+2, randomized.length() - 1));
            if(!substring.equals("")) {
                challenge.add(substring);
            }
        }
        if(rng.nextBoolean()) {
            int i = rng.nextInt(1, challenge.size());
            String first = challenge.get(i - 1);
            String second = challenge.get(i);
            String segment = first + second;
            challenge.set(i-1, segment.substring(0, 1));
            challenge.set(i, segment.substring(1));
        }
        return challenge;
    }

}
