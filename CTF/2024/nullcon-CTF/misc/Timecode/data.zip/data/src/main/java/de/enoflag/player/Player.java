package de.enoflag.player;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.Instant;
import java.util.UUID;

import de.enoflag.util.Constants;
import de.enoflag.util.ObfuscationUtil;
import de.enoflag.util.FlagUtil;
import de.enoflag.util.Pair;
import de.enoflag.util.RngUtil;

public class Player {
    private String id;
    private Socket socket;
    public PrintWriter out;
    public BufferedReader in;
    public Instant activity;
    private int count;
    private Instant timestamp;
    public Pair pair;
    

    public Player(Socket socket) throws Exception {
        this.id = String.valueOf(UUID.randomUUID());
        this.socket = socket;
        this.out = new PrintWriter(socket.getOutputStream(), true);
        this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.activity = Instant.now();
        this.count = 0;
        this.out.println("Registered as user " + this.id);
    }

    public void newChallenge() throws Exception {
        this.timestamp = Instant.now();
        try {
            while(this.in.ready()) {
                this.in.readLine();
            }
        } catch (IOException ioe) {
            System.out.println("Inputstream is closed.");
        }
        this.pair = RngUtil.getMapping(this.timestamp);
        StringBuilder stringBuilder = new StringBuilder();
        for(String part: pair.getFirst()) {
            stringBuilder.append(" " + part);
        }
        out.println("\nNew Challenge (" + String.valueOf(this.timestamp) + ")");
        out.println(stringBuilder.substring(1).toString());
    }

    private void checkSuccess() throws Exception {
        this.count += 1;
        if(this.count < 10) {
            this.out.println("Success! " + (10 - this.count) + " challenges remain.");
        } else {
            this.out.println(Constants.Messages.SUCCESS);
        }
        this.checkAndPrintFlag();
        this.newChallenge();
    }

    private void checkAndPrintFlag() throws IOException {
        if(this.count >= 10) {
            System.out.println(socket.getInetAddress() + ":" + socket.getPort() + "\t Player: " + this.id + "\n\t GOT THE FLAG @ " + Instant.now());
            this.out.println(FlagUtil.getFlag());
            this.bye();
        }
    }

    public void handle() throws Exception {
        this.activity = Instant.now();

        String input = this.in.readLine();
        String[] fields = input.split(" ");

        if(fields.length != pair.getFirst().length) {
            out.println(Constants.Messages.WRONG_LENGTH + pair.getFirst().length);
            this.bye();
            return;
        }

        RngUtil.s(this.pair);

        int i = 0;
        boolean success = true;
        try {
        for(String field : fields) {

            String comparedObj = null;

            try {
                comparedObj = String.valueOf((Integer) Integer.parseInt(field));
            } catch(NumberFormatException nfe) {
                this.out.println(String.valueOf(field) + " is not an Integer!");
                this.bye();
            }

            while(comparedObj.length() < pair.getFirst()[i].length()) {
                comparedObj = "0" + comparedObj;
            }

            if(!(comparedObj.equals(pair.getFirst()[i]))) {
                out.println("'" + comparedObj + "' is not equal to '" + pair.getFirst()[i] + "'");
                success = false;
            }

            i++;
        }
    } catch(Exception e) {
        e.printStackTrace();
    }
        RngUtil.r();

        if(!success) {
            out.println(Constants.Messages.FAIL);
            this.bye();
            return;
        }

        this.checkSuccess();
    }

    public String getId() {
        return this.id;
    }

    public void bye() {
        this.out.println(Constants.Messages.CLOSED_CONNECTION);
        this.count = 0;
        this.out.close();
        try {
            this.in.close();
        } catch (IOException e) {
            System.err.println(Constants.Messages.EXCEPTION_IS);
            e.printStackTrace();
        }
        try {
            this.socket.close();
        } catch (IOException e) {
            System.err.println(Constants.Messages.EXCEPTION_SOCK);
            e.printStackTrace();
        }
        
    }
}
