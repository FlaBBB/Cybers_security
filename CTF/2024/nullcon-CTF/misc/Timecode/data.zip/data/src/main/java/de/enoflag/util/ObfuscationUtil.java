package de.enoflag.util;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class ObfuscationUtil {
    public static SecretKey generateKey(int n) throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance(Constants.ALGORITHM);
        keyGenerator.init(n);
        return keyGenerator.generateKey();
    }

    public static SecretKey getKeyFromString(String key) throws NoSuchAlgorithmException, InvalidKeySpecException {
        SecretKeyFactory factory = SecretKeyFactory.getInstance(Constants.FACTORY_INSTANCE);
        KeySpec spec = new PBEKeySpec(key.toCharArray(), key.getBytes(), Constants.SIZE * Constants.SIZE * 4, 2 * Constants.SIZE);
        SecretKey secret = new SecretKeySpec(factory.generateSecret(spec).getEncoded(), Constants.ALGORITHM);
        return secret;
    }

    public static String encrypt(String toEncrypt) {
        try {
            SecretKey secretKey = getKeyFromString(Constants.KEY);
            Cipher cipher = Cipher.getInstance(Constants.ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            return Base64.getEncoder().encodeToString(cipher.doFinal(toEncrypt.getBytes("UTF-8")));
        } catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String decrypt(String toDecrypt) {
        try {
            SecretKey secretKey = getKeyFromString(Constants.KEY);
            Cipher cipher = Cipher.getInstance(Constants.ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            return new String(cipher.doFinal(Base64.getDecoder().decode(toDecrypt)));
        } catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
