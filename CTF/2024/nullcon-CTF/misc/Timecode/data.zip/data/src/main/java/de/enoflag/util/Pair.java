package de.enoflag.util;

public class Pair {
    private String[] first = null;
    private String[] second = null;

    public Pair(String[] first, String[] second) {
        this.first = first;
        this.second = second;
    }

    public String[] getFirst() {
        return this.first;
    }

    public String[] getSecond() {
        return this.second;
    }
}
