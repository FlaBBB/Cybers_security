package de.enoflag.util;

public interface Constants {
    public static final String FLAG_PATH = "/flag/flag.txt";
    public static final int LEET = 1337;
    public static final int ANSWER = 42;
    public static final int SIZE = 128;
    public static final String C  = "chxPxQCXzRXQNPTCRsW5w3EUoPTHTGcN9jApr4eJ2vg=";
    public static final String F = "LlOo7EKNpqAnpwNjUe8JEg==";
    public static final String DEFAULT_FLAG = "rzEeHOF3cObgZPZo09tyxlg8jYWdCRKw/AgzJpZSeco=";
    public static final int PORT = 5015;
    public static final String KEY = "SecretNullCon";
    public static final String ALGORITHM = "AES";
    public static final String FACTORY_INSTANCE = "PBKDF2WithHmacSHA256";

    public interface Messages {
        public static final String CLOSED_CONNECTION = "Connection closed.";
        public static final String WRONG_LENGTH = "Wrong input format. Expected length: ";
        public static final String SUCCESS = "Success! All challenges have been solved.";
        public static final String ERROR = "An error occured, closing connection.";
        public static final String FAIL = "Challenge failed.";
        public static final String EXCEPTION_IS = "Exception: Unable to close input stream.";
        public static final String EXCEPTION_SOCK = "Exception: Unable to closed socket.";
    }
}
