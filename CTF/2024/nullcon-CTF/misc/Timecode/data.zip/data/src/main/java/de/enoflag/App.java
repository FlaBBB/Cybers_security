package de.enoflag;

import java.io.IOException;
import java.net.*;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import de.enoflag.player.Player;
import de.enoflag.util.Constants;

public class App {
    
    private static ServerSocket serverSocket;
    

    private static ConcurrentHashMap<Socket, Player> clients = new ConcurrentHashMap<>();
    private static AtomicBoolean running = new AtomicBoolean(true);

    private static void startHandler() throws Exception {
        new Thread(() -> {
            while(running.get()) {
                for(Map.Entry<Socket, Player> entry : clients.entrySet()) {
                    if(entry.getKey().isClosed()) {
                        System.out.println("Closed Connection. Removing Player " + entry.getValue().getId() + " (" + connectionData(entry.getKey()) + ")");
                        clients.remove(entry.getKey());
                    }
                    if(Math.abs(ChronoUnit.SECONDS.between(entry.getValue().activity, Instant.now())) > 60 ) {
                        System.out.println("BYE. Removing Player " + entry.getValue().getId() + " due to inactivity. (" + connectionData(entry.getKey()) + ")");
                        entry.getValue().bye();
                        clients.remove(entry.getKey());
                    }
                }
                clients.forEach((socket, player) -> {
                    try {
                        if(player.pair == null) {
                            player.newChallenge();
                        }
                        if(player.in.ready()) {
                            player.handle();
                        }
                    } catch(Exception e) {
                        player.out.println(Constants.Messages.ERROR);
                        player.bye();
                        e.printStackTrace();
                    }
                });
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private static void start(int port) throws Exception {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            running.set(false);
            try {
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }));
        startHandler();
        serverSocket = new ServerSocket(port);
        while (running.get()) {
            Socket clientSocket = serverSocket.accept();
            Player player = new Player(clientSocket);
            clients.put(clientSocket, player);
            System.out.println("Received connection from " + connectionData(clientSocket) + "\n\tAdding Player " + player.getId());
        }
    }

    private static String connectionData(Socket socket) {
        return socket.getInetAddress() + ":" + socket.getPort();
    }

    public static void main(String[] args) throws Exception {
        start(Constants.PORT);
    }
}