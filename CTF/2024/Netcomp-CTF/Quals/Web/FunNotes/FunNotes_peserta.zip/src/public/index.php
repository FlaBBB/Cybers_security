<?php
error_reporting(0);
session_start();

require '../vendor/autoload.php';

$router = require '../app/Routes/index.php';
