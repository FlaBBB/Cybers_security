# DGA Detection
Machine learning that detecting DGA Domain (Domain Generation Algorithm)
