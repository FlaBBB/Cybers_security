## deployment steps:
- sudo docker build -t challenge_name .
- sudo docker run -d -p 5000:5000 challenge_name

## remove the container
- sudo docker ps
- sudo docker stop <container_id>
