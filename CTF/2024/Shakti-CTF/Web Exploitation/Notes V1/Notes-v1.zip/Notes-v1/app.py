from flask import Flask, request, render_template, redirect, url_for
from werkzeug.serving import WSGIRequestHandler
import os 
import yaml
from yaml import *
import uuid
from threading import Thread

app = Flask(__name__)
notes = []


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        note_id = str(uuid.uuid4())
        notes.append({'id': note_id, 'title': title, 'content': content})
        return redirect(url_for('index'))
    else:
        return render_template('index.html', notes=notes)

@app.route('/add_note', methods=['POST'])
def add_note():
    title = request.form['title']
    content = request.form['content']
    note_id = str(uuid.uuid4())
    notes.append({'id': note_id, 'title': title, 'content': content})
    return render_template('index.html', notes=notes)

@app.route('/edit_note/<note_id>', methods=['GET', 'POST'])
def edit_note(note_id):
    note = next((note for note in notes if note['id'] == note_id), None)
    if note:
        if request.method == 'POST':
            title = request.form['title']
            content = request.form['content']
            note['title'] = title
            note['content'] = content
            return redirect(url_for('index'))
        else:
            return render_template('edit.html', note=note)
    else:
        return 'Note not found', 404

@app.route('/admin', methods=['GET'])
def serialize():
    data=request.args.get('data')
    if data:
        deserialized=yaml.load(data,Loader=Loader)
        return deserialized
    else:
        return "No data provided"
    
    
if __name__ == '__main__':
    WSGIRequestHandler.protocol_version = "HTTP/1.1"
    app.run(host='0.0.0.0', port=5000, threaded=True, debug=False)


