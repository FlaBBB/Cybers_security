package main

import (
	"log"
	"net/http"
	"net/http/httputil"
	"net/url"
)

type loggingResponseWriter struct {
	http.ResponseWriter
}

func (lrw *loggingResponseWriter) Write(b []byte) (int, error) {
	log.Printf("Response Body: %s\n", string(b))
	return lrw.ResponseWriter.Write(b)
}

func loggingHandler(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		lrw := &loggingResponseWriter{w}
		h.ServeHTTP(lrw, r)
	})
}

func main() {
	origin, err := url.Parse("http://localhost:5000")
	if err != nil {
		panic(err)
	}
	proxy := httputil.NewSingleHostReverseProxy(origin)
	http.DefaultTransport.(*http.Transport).MaxIdleConns = 500
	http.DefaultTransport.(*http.Transport).MaxIdleConnsPerHost = 100
	http.Handle("/", loggingHandler(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/admin" {
			http.Error(w, "Access to /admin is prohibited", http.StatusForbidden)
			return
		}
		proxy.ServeHTTP(w, r)
	})))
	log.Println("Server started at :8000...")
	log.Fatal(http.ListenAndServe(":8000", nil))

}
