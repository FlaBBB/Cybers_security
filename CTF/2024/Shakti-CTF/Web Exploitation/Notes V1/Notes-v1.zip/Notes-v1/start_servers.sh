#!/bin/bash
python3 app.py &
# Start the Go reverse proxy
reverse_proxy 
# Start the Python server using Werkzeug

