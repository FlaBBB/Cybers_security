void main(){
    char buf[0x20];
    write(1, "༼ つ ◕_◕ ༽つ ::::::: ", 0x20);
    read(0, buf, 0x80);
}