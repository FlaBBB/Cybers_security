const secret = "[REDACTED]";
exports.value = secret;