# TahuBulat

**Category:** pwn
## Description
>Dadakan<br><br>Hint : overwrite GOT?<br><br>[attachment](https://drive.google.com/uc?export=download&id=1VGBshi5xeEveg0baVtEpm3iTHGTX9DwK)<br><br>Author: `ZafiN`

## Service
>nc 103.181.183.216 17005

## Solution

## Flag