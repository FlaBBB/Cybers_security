# Rangkaian Digital

**Category:** pwn
## Description
>Selamat datang di pertemuan mata kuliah Rangkaian Digital! Materi hari ini adalah bilangan biner! <br><br>[attachment](https://drive.google.com/drive/folders/1yhDbtSG5QEcHZWw2WPzsih34x4R1mKb4?usp=sharing)<br><br>Author: `z__ran`

## Hint
* These leave instructions are so annoying man.... But I maybe able to use it to my advantage with that 2 byte overflow. Let me just teleport the stack around first to assemble my rop chain.
* this should help bypass cool_thing2 and cool_thing3 https://baseconvert.com/ieee-754-floating-point
* stack pivot ke akhir bss -> pake cool_thing2 buat nyusun ropchain -> pindahin rbp buat leak libc pake cool_thing3 -> pake got strstr buat gadget leave biar pivot ke bss lagi dan one_gadget deh ato ngga ret2syscall

## Service
>nc 103.181.183.216 17003

## Solution

## Flag