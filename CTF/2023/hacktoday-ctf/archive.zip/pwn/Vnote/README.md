# Vnote

**Category:** pwn
## Description
>cpP enjoyer<br><br>[attachment](https://drive.google.com/uc?export=download&id=1wWTWI4wpws38urBohpNmBMatqIX7DI1M)<br><br>Author: `luqman`

## Service
>nc 103.181.183.216 17002

## Solution

## Flag