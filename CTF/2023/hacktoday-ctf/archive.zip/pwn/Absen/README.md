# Absen

**Category:** pwn
## Description
>hint : did u see any memory address in memory address why don't just point it to another memory address, and hipiti hopiti win<br><br>[attachment](https://drive.google.com/uc?export=download&id=1LOP1EQlfPJ1sT2lS2J2RFMOMqEgbq0Z7)<br><br>Author: `yqroo`

## Service
>nc 103.181.183.216 17000

## Solution

## Flag