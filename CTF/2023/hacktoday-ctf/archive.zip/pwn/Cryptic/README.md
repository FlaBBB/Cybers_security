# Cryptic

**Category:** pwn
## Description
>A lot of weird pwn challs lately, let's stick to the stack for now.<br><br>[attachment](https://drive.google.com/drive/folders/1XmZBws-vSq2ut67BDPwoKkAVHr0h3VQs?usp=sharing)<br><br>Author: `z__ran`

## Hint
* If you're only getting part of the flag, your leak is too short. You should try leaking further.

## Service
>nc 103.181.183.216 17001

## Solution

## Flag