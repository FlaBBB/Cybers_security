# celestial carnival

**Category:** osint
## Description
>in a whimsical dance, confetti elephants joyfully paraded through cotton candy clouds.<br><br>Author: `kelapacuyy`

## Hint
* look through the account details, you might find something useful
* watch closely for the capitalized words, I think they can refer to something...
* wait, did she say something about a city? and social media?

## Solution

## Flag