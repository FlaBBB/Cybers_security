# MUA

**Category:** osint
## Description
>Aku akhir-akhir ini sangat suka sekali make up >< aku juga menyukai salah satu make up artist asal korea. AH!! aku lupa namanya, tapi dia adalah orang yang ada di gambar ini. Aku sangat menyukai make up hasilnya. Selain jago make up dia juga jago menggambar. Aku meninggalkan komentar beberapa hari yang lalu untuk menyemangatinya di salah satu video di channel youtubenya. Video itu berisi vlog dia sedang menggambar.<br><br>[attachment](https://drive.google.com/drive/u/0/folders/1xbu4MeedX52g4luMbzrVuHP4XHAkpXgf)<br><br>Author: `glitchgoo`

## Solution

## Flag