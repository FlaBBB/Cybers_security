# Initial Point

**Category:** osint
## Description
>Description<br><br>A young child named Khawf has mysteriously gone missing somewhere near a bus stop. I managed to get a snippet of security camera footage capturing his last sighting before the connection unexpectedly dropped. Can you help me find the street name, postal code, and the name of the company responsible for the surveillance, which will allow me to retrieve the complete footage and hopefully find Khawf.<br><br>
Flag format : hacktoday{Street Name_Postal Code_Company Name}<br><br>P.S. write everything in latin alphabet<br><br>[attachment](https://mega.nz/file/hik3UCBR#urCyGfMdxo2HOBEFee4fXAJ5TRH_fGYMG-FgXT4PJgQ)<br><br>Author: `kelapacuyy`

## Solution

## Flag