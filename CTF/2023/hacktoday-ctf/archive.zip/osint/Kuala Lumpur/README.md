# Kuala Lumpur

**Category:** osint
## Description
>Beberapa tahun yang lalu, aku pergi ke Kuala Lumpur. Suatu sore di sana, aku naik LRT satu kali dari KL Sentral untuk menuju ke sebuah kawasan di KL. Sekeluarnya aku dari stasiun tujuanku, aku dapat melihat menara kembar Petronas dengan jelas, karena memang letak kawasan ini dekat dengan KLCC. Namun setelah itu, aku berbalik arah menuju utara dan menemukan semacam pasar malam yang menjual berbagai street food khas Malaysia. Aku melanjutkan perjalananku ke arah barat dan utara dan akhirnya sampai di suatu Masjid Jamek.<br><br>Ketika berada di masjid, aku memotret sebuah gambar yang merupakan menara utama masjid. Saat itu merupakan waktu menjelang matahari terbenam dan rupanya, aku juga memotret sebuah benda langit yang berupa sebuah titik putih dan letaknya ada di samping menara. Oh iya, satu hal yang kuingat, ketiga tempat yang kusebutkan di atas (stasiun, pasar malam, dan masjid jamek), semuanya memiliki nama yang sama dengan nama kawasan tersebut. <br><br>[attachment](https://drive.google.com/drive/folders/1J18SQqHYb3xH_eFmeI6am6M7CPbgnzqQ?usp=sharing)<br><br>Author: `ghifar`

## Hint
* google "star position tool"

## Solution

## Flag