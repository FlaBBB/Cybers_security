# Link Rahasia

**Category:** rev
## Description
>jangan sampai salah link yah :><br><br>[attachment](https://drive.google.com/uc?export=download&id=181_h8v6OR8nOs14jZ8m3T9FR1EApt3Cy)<br><br>Author: `compe_`

## Hint
* Did you notice that the 'checker' actually got checked?
* Confused about the algorithm? Try using the 'theorem prover'!

## Solution

## Flag