# OnlyAdminCanSee

**Category:** rev
## Description
>my friend sent a file to me and he asked me to hack an application that Mr. John can login. Can you help me reversing it so im able to see what is inside? Help him to login to the app<br><br>[attachment](https://drive.google.com/uc?export=download&id=1Kn8kHynyqmnWJkJWPNkbEOA8B5hsZqiU)<br><br>Author: `encryptedscripts`

## Solution

## Flag