# Gacorr flag gen

**Category:** rev
## Description
>My friend Yudo just have sent me a flag generator but i saw something sus. He said the flag generator can makes you defeat the boss and get the enemies flag. <br><br>[attachment](https://cdn.discordapp.com/attachments/1025767334901727363/1144896202240954428/FlagGen.exe)<br><br>Author: `encryptedscriptss`

## Solution

## Flag