# kurang-lebih+

**Category:** rev
## Description
>siapa yang benci soal beranak??, well here we go<br><br>NOTE : hacktoday{String  yang ditemukan}<br><br>[attachment](https://drive.google.com/uc?export=download&id=1cf3211KcUOY4z3KGlDth1Ss2Y5X5l1U3)<br><br>Author: `yqroo`

## Hint
* If something goes wrong why don't just debug it ^-^

## Solution

## Flag