# Nyicil

**Category:** rev
## Description
>Nyicil dulu, nanti juga lunas<br><br>[attachment](https://drive.google.com/uc?export=download&id=1lRe9NuiMKiyY7ZI8zkapADS3-aGmjQON)<br><br>Author: `anro128`

## Hint
* cicilan sangatlah penting

## Solution

## Flag