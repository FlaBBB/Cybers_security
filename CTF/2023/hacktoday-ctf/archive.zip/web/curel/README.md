# curel

**Category:** web
## Description
><br><br>[attachment](https://mega.nz/file/3BoDSQ7L#f_zQw1gXTAcKgUMZyinRur2uCGIEqnkRMbFUHIQbrQo)<br><br>Author: `linz`

## Service
>http://103.181.183.216/<br>http://103.181.183.216:16009

## Solution

## Flag