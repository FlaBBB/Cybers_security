# LogInspek

**Category:** web
## Description
>Mr. Robot trying to get his revenge to a hacker website and need to login as an admin, but seems like there is no backend? well we dont know. Thats why Mr. Robot asked John the Inspector to help him to get the flag.<br><br>Author: `encryptedscripts`

## Service
>https://loginspek.netlify.app/

## Solution

## Flag