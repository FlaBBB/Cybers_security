# Codebin-JS

**Category:** web
## Description
>CodeBin is a mini pastebin-like web application that allows users to post and share their code snippets with others who have registered on the site. It provides a platform for developers to easily share and discover code examples, collaborate, and learn from each other. A hacker named Paul just found the website is having vulnerability that allow users to access the admin page. He told the developer about this but he don't want to tell the way. The developer hired a pentester to find out how to get access as admin to the page, help the developer to find out!<br><br>Author: `encryptedscripts`

## Hint
* The hacker got a message from Mr. X-Mark. Mr. X-Mark said, "It looks like Pico's Cookie but not a cookie, admin and users login only one and no admin account"

## Service
>http://103.181.183.216:16003/

## Solution

## Flag