# booktoday

**Category:** web
## Description
>Welcome to the bookshop of choice for all literature enthusiasts! Explore our comprehensive collection that spans various genres and renowned authors, offering everything from affordable books to exclusive and premium editions.<br><br>Author: `compe_`

## Hint
* Users will not be able to download books that have not been purchased because the button will not appear B). (very safe)

## Service
>103.181.183.216:16005

## Solution

## Flag