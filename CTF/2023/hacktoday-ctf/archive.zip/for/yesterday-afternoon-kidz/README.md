# yesterday-afternoon-kidz

**Category:** for
## Description
>Our live proxy has detected hacking activity in our logs; analyze the log file to find out what data the hacker retrieved <br><br>[attachment](https://drive.google.com/uc?export=download&id=1rpDhgsnsBwRsi_McoRyuw6ZBI0BpKx80)<br><br>Author: `arai`

## Solution

## Flag