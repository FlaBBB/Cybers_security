# dummy

**Category:** for
## Description
>SOC team noticed a strange activity in which a file was being shared within our system. For safety reason, forensic team dumped the virtualization memory to analyze the file further. However, it turned out to be just a message that was shared by nobody, but maybe you still need to see that message. <br><br>password: https://pastebin.com/nKbPGB79<br><br>[attachment](https://mega.nz/file/jdYgVaYb#UildAghTAEt7K8bcZzGFYnIsHKF_Qc4WebUQ_t3HRZ8)<br><br>Author: `arai`

## Hint
* vola3
* maybe you can use basic file carving and extractor 
gaming
* this is linux memdump,  and it is highly recommended to build a profile beforehand

## Solution

## Flag