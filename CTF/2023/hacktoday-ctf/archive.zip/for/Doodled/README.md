# Doodled

**Category:** for
## Description
>Oh no! My cousin Gio Ferdiansyah has scribbled all over my stuff! Almost everything is covered with his doodles, including an important QR code, making it unreadable. Can you help me retrieve the lost information? <br><br>[attachment](https://drive.google.com/uc?export=download&id=1PnJXzwNQykEMxOcv4VEH_VZTAUCRMZaH)<br><br>Author: `kelapacuyy`

## Solution

## Flag