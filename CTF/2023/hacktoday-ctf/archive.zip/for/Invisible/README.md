# Invisible

**Category:** for
## Description
>I could've sworn I saw something, or maybe not...<br><br>[attachment](https://drive.google.com/uc?export=download&id=104dC2o0WNXBqLMNaHm9AMs0nCoFhLJOu)<br><br>Author: `z__ran`

# Hint
* these black and white pixels...they grew...?
* jadi seharusnya ada hint di file zip nya, tapi kuulangi aja disini, "look very closely near the third part, i swear i saw something"
* like I said, black = 0, white = 1
* after part 3/4, try using https://stegonline.georgeom.net/upload to get the hint to part 4/4 (atau bisa ngedukun aja sih gaperlu hintnya)
* unicode

## Service
>https://stegonline.georgeom.net/upload to get the hint to part 4/4 (atau bisa ngedukun aja sih gaperlu hintnya)

## Solution

## Flag