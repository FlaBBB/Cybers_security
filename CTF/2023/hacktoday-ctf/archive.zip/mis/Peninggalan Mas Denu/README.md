# Peninggalan Mas Denu

**Category:** mis
## Description
>Mas Denu adalah mentor Yudo yang sudah lama hilang. Beliau menghilang setelah berpergian ke kota Erdogan untuk mencari vaksin Yandex-69. Saat mengerjakan laprak, Yudo teringat kata-kata terakhir Mas Denu sebelum menghilang, "jika kamu ingin mengetahui rahasia untuk menjuarai ICPC, jawabannya ada pada soal <problem.HAHA> dengan input berupa <testcase69.txt> yang dijalankan pada program <decrypt_program.cpp>. Namun, karena teman Yudo yang bernama Visco Vernandez merasa iri karena tidak bisa menyelesaikan soal tersebut, dia melakukan "sesuatu" kepada soal yang diberikan Mas Denu.<br><br>[attachment](https://drive.google.com/uc?export=download&id=1v96EjlACUPo2bAsmQT5OQr6u9ly4DuET)<br><br>Author: `ln y`

## Solution

## Flag