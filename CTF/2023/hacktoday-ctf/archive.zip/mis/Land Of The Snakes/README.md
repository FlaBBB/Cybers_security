# Land Of The Snakes

**Category:** mis
## Description
>Basic calculator<br>https://youtu.be/Jhbj4jaJSu8<br><br>[attachment](https://drive.google.com/uc?export=download&id=1cA4T3fQWCjyujxQUrnx5dkgojkoQKedQ)<br><br>Author: `patsac`

## Hint
* i think we need to eliminate some bothering functions. but how?
* something new in python3.8 might help.

## Service
>nc 103.181.183.216 19002

## Solution

## Flag