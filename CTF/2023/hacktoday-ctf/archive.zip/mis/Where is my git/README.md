# Where is my git?

**Category:** mis
## Description
>I just playing around with git command, and suddenly, my flag (i mean, my git) is disappear. Can you find it for me?<br><br>[attachment](https://drive.google.com/uc?export=download&id=1NWxbz-Sfu1-Zu-NmKQknIfncXY2LQgEv)<br><br>Author: `jedi`

## Solution

## Flag