# DCHEZKIBOXS

**Category:** mis
## Description
>Kali ini Pak Masse menemukan sebuah port aneh yang berisi kalimat rahasia. Untuk melihat kalimat tersebut ia diminta memasukan password berupa Substring terpajang pertama dari string yang diberikan port tersebut yang merupakan "kata DCHEZKIBOXS". Sebuah string dikatakan "kata DCHEZKIBOXS" jika dan hanya jika string tersebut dibelah dua secara horizontal kedua bagian string (atas dan bawah) akan membentuk bagian yang seimbang dan dapat dibentuk menjadi sama persis jika beberapa bagiannya dirotasi. Contoh: "CHECK" merupakan salah satu "kata DCHEZKIBOXS" karena ketika belah dua kedua bagian akan membentuk bagian yang seimbang. visualisasi contoh dapat dilihat di bagian "attachement". Karena string yang diberikan sangat panjang, untuk menemukan passwordnya Pak Masse menggeser-geser jendela ruangannya atau memainkan dua buah pointer miliknya untuk mendapatkan berbagai inspirasi.<br><br>[attachment](https://drive.google.com/uc?export=download&id=1FhlBfwibXF8uJkiJmkVMX52HLjEins0C)<br><br>Author: `anro128`

## Service
>nc 103.181.183.216 19001

## Solution

## Flag