# Spam

**Category:** cry
## Description
>Today is your birthday, your friends send you a file that has password on it. They said the password will be send from fake email. But because of your birthday, many people send you an email. Here's what you got on email.<br><br>[attachment](https://drive.google.com/uc?export=download&id=10fQNcGPsMxy1kgfKdysSoMMhnblsxNsy)<br><br>Author: `bims_kuy`

## Service
>nc 103.181.183.216 18001

## Solution

## Flag