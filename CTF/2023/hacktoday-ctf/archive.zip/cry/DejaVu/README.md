# DejaVu

**Category:** cry
## Description
>have you ever seen LCG used as key generator in stream cipher? if you haven't, this is the time<br>https://youtu.be/oigcRpBOoZk<br><br>[attachment](https://drive.google.com/uc?export=download&id=1ze6DuayWA2pMbKQl4-ObBJXQ6EkNS-43)<br><br>Author: `patsac`

# Hint 
* did u have enough sleep?
* n = getPrime(105)

## Service
>nc 103.181.183.216 18000

## Solution

## Flag