# AES Enjoyer

**Category:** cry
## Description
>Legenda mengatakan, "CTF gak afdhol kalo di crypto gak ada aes-nya"<br><br>[attachment](https://drive.google.com/uc?export=download&id=14C976J14Aplksp3TDqcee29PTWeM8rYS)<br><br>Author: `kiaraa09`

## Service
>nc 103.181.183.216 18002

## Solution

## Flag