# Reverse RSA

**Category:** cry
## Description
>Zantos was too bored with plain RSA so he tried create a cipher by reversing the RSA. is it secure??<br><br>[attachment](https://drive.google.com/uc?export=download&id=1RlDzprIw10U7_tLojmPRO6i5v3qsjMsX)<br><br>Author: `kiaraa09`

## Hint
* LLL is one of many way to recover random key

## Solution

## Flag