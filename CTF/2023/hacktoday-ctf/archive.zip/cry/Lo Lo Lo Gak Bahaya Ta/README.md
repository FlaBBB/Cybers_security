# Lo Lo Lo Gak Bahaya Ta?

**Category:** cry
## Description
>Bahaya Gak Sih?.<br><br>[attachment](https://drive.google.com/uc?export=download&id=1z9lb_07wQJ6LHY5vufqM3p5VY6pKaHfV)<br><br>Author: `ZafiN`

## Hint
* Is private key vector is the shortest basis? 

## Solution

## Flag