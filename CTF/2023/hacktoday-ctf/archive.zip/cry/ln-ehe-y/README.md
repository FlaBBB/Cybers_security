# ln-ehe-y

**Category:** cry,mis
## Description
>Pada suatu hari, ada seorang anak yang sedang berkendara menggunakan motor. Ketika dia sedang...<br><br>dahlah males ngarang cerita kerjain ajh pokoknya (^_^)<br><br>[attachment](https://drive.google.com/uc?export=download&id=1QiNd2QegxDR34yyc-XoRfuBktwlvTxF7)<br><br>Author: `ln y`

# Hint
* udah ada 3 hint, cek di discord ajah hintnya sudah aku up

## Service
>nc 103.181.183.216 18008

## Solution

## Flag