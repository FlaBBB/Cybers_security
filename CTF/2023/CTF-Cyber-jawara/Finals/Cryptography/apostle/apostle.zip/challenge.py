from os import urandom
from hashlib import sha512
from Crypto.Util.strxor import strxor

from aes import *

FLAG = open('flag.txt', 'rb').read()
master_key = urandom(16)
flag_key = sha512(master_key).digest()
enc_flag = strxor(FLAG, flag_key[:len(FLAG)])

plaintext = urandom(16)
plain_state = bytes2matrix(plaintext)
key_matrices = expand_key(master_key, 1)

add_round_key(plain_state, key_matrices[0])
sub_bytes(plain_state)
shift_rows(plain_state)
mix_columns(plain_state)
add_round_key(plain_state, key_matrices[1])

ciphertext = matrix2bytes(plain_state)

print(f"Protected flag: {enc_flag.hex()}")
print(f"Plaintext: {plaintext.hex()}")
print(f"Ciphertext: {ciphertext.hex()}")

print(f"Hint 1: {master_key[0]}")
print(f"Hint 2: {master_key[-1]}")
print(f"Hint 3: {master_key[-2]}")