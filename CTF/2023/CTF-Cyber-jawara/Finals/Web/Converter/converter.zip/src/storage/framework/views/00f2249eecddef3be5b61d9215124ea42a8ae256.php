<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SVG to PNG Converter</title>
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6"
        crossorigin="anonymous">
    <style>
        .main {
            margin: 5em auto;
            width: 50%;
        }
        .registration {
            margin: 2em auto;
        }
        .form-group {
            margin: 1em auto;
        }
    </style>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>
<div class="main">
    <h1>SVG to PNG Converter</h1>
    <?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger alert-block">
        <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>
    <form class="registration" method="POST" action="/" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="g-recaptcha" data-sitekey="6LfmVSMpAAAAAGNELwUw0qSfoniwb_RVFTsbn2D9"></div>
        <div class="form-group">
            <label for="photo">Upload SVG</label>
            <input type="file" class="form-control" name="source">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Convert</button>
        </div>
    </form>
</div>
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf"
    crossorigin="anonymous">
</script>
</body>
</html><?php /**PATH /var/www/converter/resources/views/index.blade.php ENDPATH**/ ?>