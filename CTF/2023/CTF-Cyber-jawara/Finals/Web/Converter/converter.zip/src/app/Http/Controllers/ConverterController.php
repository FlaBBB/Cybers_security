<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use SVG\SVG;
use SVG\Nodes\Shapes\SVGCircle;
use SVG\Nodes\Structures\SVGGroup;
use SVG\Nodes\Text\SVGText;
use SVG\Nodes\Embedded\SVGImage;


class ConverterController extends Controller
{
    public function index() {
        return view('index');
    }

    public function convert(Request $request) {
        $recaptchaSecret = '6LfmVSMpAAAAAKMbJMiYc1MQvjSydkdJVVJAbgMU';
        $recaptchaResponse = $request->input('g-recaptcha-response');
    
        $url = 'https://www.google.com/recaptcha/api/siteverify';
        $data = [
            'secret' => $recaptchaSecret,
            'response' => $recaptchaResponse,
            'remoteip' => $_SERVER['REMOTE_ADDR']
        ];
    
        $options = [
            'http' => [
                'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                'method' => 'POST',
                'content' => http_build_query($data)
            ]
        ];
    
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $resultJson = json_decode($result);
    
        if ($resultJson->success != true) {
            return redirect()->back()->with('error', 'reCAPTCHA validation failed');
        }

        $randomString = random_bytes(32);
        $randomHex = bin2hex($randomString);
        $id = hash('sha256', $randomHex);
        try {
            if ($request->file('source') !== null) {
                $ext = $request->file('source')->getClientOriginalExtension();
                if ($ext === 'svg') {
                    $file_name = $id . '.' . $ext;
                    $request->file('source')->move(resource_path('images') . '/', $file_name);
                    $path = resource_path('images') . '/' . $file_name;
                    $content = file_get_contents($path);
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $type = finfo_buffer($finfo, $content);
                    finfo_close($finfo);
                    $type = mime_content_type($path);
                    if (strpos($type, 'image/svg') === 0 && mb_stripos($content, 'phar://') === false) {
                        $svg = SVG::fromFile($path);
                        $width = $svg->getDocument()->getHeight();
                        $height = $svg->getDocument()->getHeight();
                        if (empty($width)) {
                            $width = 1000;
                        }
                        if (empty($height)) {
                            $height = 1000;
                        }
                        $rasterImage = $svg->toRasterImage($width, $height);
                        header('Content-Type: image/png');
                        header('Content-Disposition: attachment; filename="' . $id . '.png"');
                        imagepng($rasterImage);
                        die();
                    } else {
                        unlink($path);
                    }
                }
            }
        } catch (\Exception $e) {
            // Pass
        }
        return redirect()->back()->with('error', 'Cannot convert file. Error ID: ' . $id);
    }
}
 