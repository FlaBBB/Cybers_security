# apocalypse [610 pts]

**Category:** Forensic
**Solves:** 12

## Description
>I pulled these two screenshot images from my old device. It was until I noticed that both of them have a flaw\xe2\x80\x94damaged chunks\r\n\r\nFlag format: `CJ2023{[a-f0-9]{20}}`

**Hint**
* The images were originally captured and `cropped` using the built-in app of a certain Android stock phone before it became damaged. Furthermore, the result may be related to a security issue

## Solution

### Flag

