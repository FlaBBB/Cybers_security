# handouts [1000 pts]

**Category:** Forensic
**Solves:** 1

## Description
>b"I received a set of handouts that required printing. Unfortunately, an issue arose, resulting in the print-jobs being paused. Additionally, it appears that the file containing the given handouts is now missing. I wonder if I can retrieve the original from the print-servers log itself."

**Hint**
* A specific DNS tunneling mechanism was previously employed to access the remote shell and retrieve the required files

## Solution

### Flag

