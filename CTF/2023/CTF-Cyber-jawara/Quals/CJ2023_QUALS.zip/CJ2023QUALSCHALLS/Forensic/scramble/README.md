# scramble [970 pts]

**Category:** Forensic
**Solves:** 2

## Description
>It might be a bit mundane to pull a FTP card every year. But this time, the abundance of request activities seems a bit scrambled. Could you still able to figure out what kind of information got compromised?

**Hint**
* b"It wasnt immediately apparent, but the FTP requests occurred simultaneously, causing the server to experience some throttling. This, in turn, led to the expected FTP-DATA becoming unordered"

## Solution

### Flag

