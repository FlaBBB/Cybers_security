# chokaro [490 pts]

**Category:** Cryptography
**Solves:** 18

## Description
>Fyi, QR code is just NxN matrix in `GF(2)`

**Hint**
* -

## Solution

### Flag

