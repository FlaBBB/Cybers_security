# daruma [490 pts]

**Category:** Cryptography
**Solves:** 18

## Description
>b"Software audit is so cringe bro, why dont we do [paper](https://is.its.ac.id/pubs/oajis/index.php/home/detail/1554/ALGORITMA-AUTHENTICATED-ENCRYPTION-PUBLIC-KEY-CRYPTO-SYSTEM-BERBASIS-CARMICHAEL-FUNCTION-AECF) audit instead\r\n\r\n`nc 178.128.102.145 50001`"

**Hint**
* -

## Solution

### Flag

