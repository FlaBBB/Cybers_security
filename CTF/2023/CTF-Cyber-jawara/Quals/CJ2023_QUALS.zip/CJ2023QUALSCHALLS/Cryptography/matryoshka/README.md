# matryoshka [940 pts]

**Category:** Cryptography
**Solves:** 3

## Description
>I invented new shared encryption mechanism to store multiple secrets into one JWT

**Hint**
* -

## Solution

### Flag

