# aeonia [940 pts]

**Category:** Cryptography
**Solves:** 3

## Description
>[Go](https://github.com/ecies/go)od luck\r\n\r\n`nc 178.128.102.145 50002`

**Hint**
* -

## Solution

### Flag

