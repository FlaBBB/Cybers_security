# Wonder Drive [850 pts]

**Category:** We
**Solves:** 5

## Description
>Wonderful file repository drive and sharing.\r\n\r\nCan you get the https://wonder-drive.ctf.cyberjawara.id/repository/wonderadmin/flag.txt?\r\n\r\nhttps://wonder-drive.ctf.cyberjawara.id

**Hint**
* -

## Solution

### Flag

