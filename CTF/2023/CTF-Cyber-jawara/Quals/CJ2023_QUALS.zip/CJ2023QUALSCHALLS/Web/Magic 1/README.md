# Magic 1 [300 pts]

**Category:** We
**Solves:** 28

## Description
>Another warmup with PHP web app.\r\n\r\nhttps://magic-1.ctf.cyberjawara.id

**Hint**
* -

## Solution

### Flag

