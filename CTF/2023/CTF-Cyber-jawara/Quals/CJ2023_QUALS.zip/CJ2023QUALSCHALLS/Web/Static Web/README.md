# Static We [300 pts]

**Category:** We
**Solves:** 63

## Description
>"Static" web for your hacking warmup.\r\n\r\nhttps://static-web.ctf.cyberjawara.id/

**Hint**
* -

## Solution

### Flag

