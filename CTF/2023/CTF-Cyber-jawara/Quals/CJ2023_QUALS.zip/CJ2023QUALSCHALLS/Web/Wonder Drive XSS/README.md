# Wonder Drive XSS [1000 pts]

**Category:** We
**Solves:** 1

## Description
>Now, exploit the Cross-Site Scripting bug on the Wonder Drive.\r\n\r\nThe `TARGET` is `wonder-drive.ctf.cyberjawara.id`.\r\n\r\nhttps://bot.wonder-drive.ctf.cyberjawara.id/

**Hint**
* -

## Solution

### Flag

