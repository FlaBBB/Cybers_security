# Magic 2 [880 pts]

**Category:** We
**Solves:** 4

## Description
>b"Is this considered as a warmup challenge? Lets find out.\r\n\r\nhttps://magic-2.ctf.cyberjawara.id/"

**Hint**
* -

## Solution

### Flag

