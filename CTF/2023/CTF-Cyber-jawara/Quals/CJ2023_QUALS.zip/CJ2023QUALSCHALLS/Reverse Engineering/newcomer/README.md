# newcomer [300 pts]

**Category:** Reverse Engineering
**Solves:** 26

## Description
>Zig is a general-purpose programming language and toolchain for maintaining robust, optimal and reusable software.

**Hint**
* -

## Solution

### Flag

