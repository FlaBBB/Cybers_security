# newager [970 pts]

**Category:** Reverse Engineering
**Solves:** 2

## Description
>This CHALLENGES Is NOT Endorsed By The Rust Foundation

**Hint**
* -

## Solution

### Flag

