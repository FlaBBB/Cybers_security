# stoneager [940 pts]

**Category:** Reverse Engineering
**Solves:** 3

## Description
>[Loop good](https://gcc.gnu.org/c99status.html)

**Hint**
* -

## Solution

### Flag

