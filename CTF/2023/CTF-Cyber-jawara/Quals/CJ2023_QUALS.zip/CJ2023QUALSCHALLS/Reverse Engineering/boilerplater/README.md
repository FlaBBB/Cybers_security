# boilerplater [940 pts]

**Category:** Reverse Engineering
**Solves:** 2

## Description
>[The Future of Programming](https://www.youtube.com/watch?v=ecIWPzGEbFc)

**Hint**
* -

## Solution

### Flag

