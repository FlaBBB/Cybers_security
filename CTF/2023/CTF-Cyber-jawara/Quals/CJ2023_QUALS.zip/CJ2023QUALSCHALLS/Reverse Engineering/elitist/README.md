# elitist [850 pts]

**Category:** Reverse Engineering
**Solves:** 6

## Description
>[Loop bad](https://elm-lang.org/)

**Hint**
* -

## Solution

### Flag

