# wordless [1000 pts]

**Category:** Misc
**Solves:** 0

## Description
>

**Hint**
* Is there an alternative method to invoke a `repr-like` function in Python 2 without directly using the `repr` itself?

## Solution

### Flag

