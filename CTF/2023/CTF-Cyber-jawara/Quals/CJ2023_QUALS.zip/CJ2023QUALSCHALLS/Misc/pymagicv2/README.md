# pymagicv2 [1000 pts]

**Category:** Misc
**Solves:** 0

## Description
>

**Hint**
* The semantics of new-style classes might allow skipping unnecessary processes that mimic class instantiation, similar to the behavior in Python 3

## Solution

### Flag

