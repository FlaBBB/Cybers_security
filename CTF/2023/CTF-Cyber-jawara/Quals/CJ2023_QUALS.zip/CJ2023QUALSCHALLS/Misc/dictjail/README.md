# dictjail [970 pts]

**Category:** Misc
**Solves:** 2

## Description
>

**Hint**
* There is a specific magic method outlined in PEP Python 3 that allows manipulation of class so that it can be pointed to other variables/functions without depending on class instantiation\n* It might not be necessary to directly spawn os/eval shell due to the limit stuff. Instead, how about try to spawn pseudo shell based-on something like `less` interface?

## Solution

### Flag

