from flask import Flask, request, render_template, redirect, url_for, session, send_from_directory
from itsdangerous import URLSafeSerializer
import hashlib
import os
import json
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_urlsafe(16)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024
app.config['UPLOAD_FOLDER'] = 'repository/'

def create_user_directory(username):
    os.makedirs(f'accounts/{username}', exist_ok=True)

def user_exists(username):
    return os.path.exists(f'accounts/{username}')

def authenticate(username, password):
    user_file = f'accounts/{username}/user.json'
    if os.path.exists(user_file):
        with open(user_file, 'r') as f:
            user_data = json.load(f)
            hashed_password = hashlib.sha256(password.encode()).hexdigest()
            return user_data['password'] == hashed_password
    return False

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg', 'gif', 'txt', 'pdf'}

def safely_join(root, path):
    resolved = os.path.join(root, path)
    abs_root = os.path.abspath(root)
    abs_resolved = os.path.abspath(resolved)
    if abs_root == os.path.commonpath([abs_root, abs_resolved]):
        return resolved
    else:
        return root

def is_accessible(accessor, full_path):
    access_file = f"accounts/{accessor}/access"
    with open(access_file, encoding="ascii") as f:
        access_list = f.read().split('\n')
        for access in access_list:
            abs_access = os.path.abspath(access)
            abs_filepath = os.path.abspath(full_path)
            if abs_filepath == os.path.commonpath([abs_access, abs_filepath]):
                return True
    return False

@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('user_repository_root', username=session['username']))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'username' in session:
        return redirect(url_for('user_repository_root', username=session['username']))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if len(username) < 10 or len(password) < 10:
            return 'Username and password must be at least 10 characters long'
        if not username.isalnum():
            return 'Username must be alphanumeric'
        if username == password:
            return "Username and password can't be the same"
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        if not user_exists(username):
            create_user_directory(username)
            with open(f'accounts/{username}/user.json', 'w') as f:
                json.dump({'username': username, 'password': hashed_password}, f)
            return redirect(url_for('login'))
        else:
            return 'User already exists'
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'username' in session:
        return redirect(url_for('user_repository_root', username=session['username']))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if authenticate(username, password):
            session['username'] = username
            return redirect(url_for('user_repository_root', username=username))
        else:
            return 'Invalid credentials'
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route('/repository/<username>/')
def user_repository_root(username):
    if 'username' not in session or session['username'] != username:
        return 'Access Denied', 403

    filepath = ''
    full_path = safely_join(app.config['UPLOAD_FOLDER'], username)
    full_path = safely_join(full_path, filepath)

    if not os.path.exists(full_path):
        os.makedirs(full_path, exist_ok=True)

    contents = []
    for item in os.listdir(full_path):
        item_path = safely_join(filepath, item)
        item_full_path = safely_join(full_path, item)
        contents.append({'name': item, 'path': item_path, 'is_file': os.path.isfile(item_full_path)})
    return render_template(
        'repository.html',
        contents=contents,
        username=username,
        current_path=filepath
    )

@app.route('/repository/<username>/<path:filepath>')
def user_repository(username, filepath):
    accessible = False

    full_path = safely_join(app.config['UPLOAD_FOLDER'], username)
    full_path = safely_join(full_path, filepath)

    if 'username' in session and session['username'] != username:
        accessor = session['username']
        if is_accessible(accessor, full_path):
            accessible = True
    elif 'username' in session and session['username'] == username:
        accessible = True
    
    if not accessible:
        return 'Access Denied', 403

    if os.path.isdir(full_path):
        contents = []
        for item in os.listdir(full_path):
            item_path = safely_join(filepath, item)
            item_full_path = safely_join(full_path, item)
            contents.append({'name': item, 'path': item_path, 'is_file': os.path.isfile(item_full_path)})
        return render_template('repository.html', contents=contents, username=username, current_path=filepath)
    elif os.path.isfile(full_path):
        return render_template(
            'preview.html',
            filepath=filepath,
            username=username,
            current_path=filepath,
            dumps=json.dumps,
            data={'owner': username, 'file_path':filepath}
        )
    else:
        return 'File not found', 404

@app.route('/download/<username>/<path:filepath>')
def download_file(username, filepath):
    accessible = False

    full_path = safely_join(app.config['UPLOAD_FOLDER'], username)
    full_path = safely_join(full_path, filepath)

    if 'username' in session and session['username'] != username:
        accessor = session['username']
        if is_accessible(accessor, full_path):
            accessible = True
    elif 'username' in session and session['username'] == username:
        accessible = True
    
    if not accessible:
        return 'Access Denied', 403

    if os.path.exists(full_path) and os.path.isfile(full_path):
        return send_from_directory(directory=os.path.dirname(full_path), path=os.path.basename(filepath))
    else:
        return 'File not found', 404

@app.route('/create_directory', methods=['POST'])
def create_directory():
    if 'username' not in session:
        return 'You are not logged in', 403

    username = session['username']
    current_path = request.form['current_path']
    directory_name = request.form['directory_name']
    directory_path = safely_join(app.config['UPLOAD_FOLDER'], username)
    directory_path = safely_join(directory_path, current_path)
    directory_path = safely_join(directory_path, directory_name)

    if not os.path.exists(directory_path):
        os.makedirs(directory_path, exist_ok=True)
        return redirect(url_for('user_repository', username=username, filepath=current_path))
    else:
        return 'Directory already exists', 400

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'username' not in session:
        return 'You are not logged in', 403

    username = session['username']
    directory = request.args.get('directory')
    user_upload_folder = safely_join(app.config['UPLOAD_FOLDER'], username)
    user_upload_folder = safely_join(user_upload_folder, directory)

    if not os.path.exists(user_upload_folder):
        os.makedirs(user_upload_folder)

    if 'file' not in request.files:
        return 'No file part', 400
    file = request.files['file']
    
    if file.filename == '':
        return 'No selected file', 400

    if file and allowed_file(file.filename):
        filename = file.filename
        file.save(safely_join(user_upload_folder, filename))
        return redirect(url_for('user_repository', username=username, filepath=directory))

    return 'Invalid file or file type'

@app.route('/share', methods=['POST'])
def share():
    if 'username' not in session:
        return 'You are not logged in', 403

    file_path = request.form['file_path']
    username = session['username']

    user_file_path = safely_join(app.config['UPLOAD_FOLDER'], username)
    user_file_path = safely_join(user_file_path, file_path)

    if not os.path.exists(user_file_path):
        return 'Cannot share the file'

    data = {"user": username, "filepath": user_file_path}
    s = URLSafeSerializer(app.secret_key)
    token = s.dumps(data)
    return token

@app.route('/accept_share/<token>', methods=['GET', 'POST'])
def accept_share(token):
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session['username']

    s = URLSafeSerializer(app.secret_key)
    try:
        data = s.loads(token)
    except:
        return 'Invalid or expired share link', 404

    if request.method == 'POST':
        access_file = f"accounts/{username}/access"
        with open(access_file, "a", encoding="ascii") as f:
            f.write(f"{data['filepath']}\n")
        return redirect(url_for('user_repository_root', username=username))

    file_info = {'filepath': data['filepath'], 'user': data['user']}
    return render_template('accept_share.html', file_info=file_info, token=token)

if __name__ == '__main__':
    app.run(port=16000, debug=False)