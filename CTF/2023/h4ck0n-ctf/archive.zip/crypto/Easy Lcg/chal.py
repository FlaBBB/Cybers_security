import random
from Crypto.Util.number import getPrime, long_to_bytes
from Crypto.Util.Padding import pad
from Crypto.Cipher import AES
import os
from secrets import a, c

class LCG:
    def __init__(self, seed):
        self.seed = seed
        self.a = a
        self.leak1_1 = ((self.a >> 138) << 138)
        self.c = c   
        self.leak1_2 = ((self.c >> 132) << 132)
        self.m = 951831591126891226445616798859389634962506017435096204719527931037946751257386453
    
    def next(self):
        self.seed = (self.seed * self.a + self.c) % self.m
        return self.seed

def easy_lcg():
    e = 102103
    seed = random.getrandbits(256)
    p1 = seed
    p2 = 0
    lcg = LCG(seed)
    leak1_1 = lcg.leak1_1
    leak1_2 = lcg.leak1_2
    m = lcg.m
    
    for i in range(2):
        p1 += lcg.next()
        p2 += lcg.next()
    p2 += lcg.next()
    
    leak2_1, leak2_2 = pow(p1, e, m), pow(p2, e, m)
    
    key = long_to_bytes(lcg.next())[:32]
    iv = os.urandom(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    
    ct = cipher.encrypt(pad(flag, 16))
    
    print(f"Encrypted Text: {ct.hex()}\nIV: {iv.hex()}\nSeed: {seed}\np2 - p1: {p2 - p1}\nLeak2_1: {leak2_1}\nLeak2_2: {leak2_2}\nLeak1_1: {leak1_1}\nLeak1_2: {leak1_2}")

easy_lcg()
