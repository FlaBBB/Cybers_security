# Easy Lcg [300 pts]

**Category:** crypto
**Solves:** 0

## Description
>You really thought , there will no be no LCG in the CTF

#### Hint 

## Solution

## Flag

