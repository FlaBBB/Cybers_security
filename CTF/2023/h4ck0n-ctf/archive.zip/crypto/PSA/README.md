# PSA [294 pts]

**Category:** crypto
**Solves:** 4

## Description
>It takes a lot of skill and time to copy signatures, can you do it quickly!!??

## Service
nc 64.227.131.98 10000

#### Hint 

## Solution

## Flag

