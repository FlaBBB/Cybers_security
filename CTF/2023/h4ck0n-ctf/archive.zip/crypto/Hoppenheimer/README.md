# Hoppenheimer [700 pts]

**Category:** crypto
**Solves:** 0

## Description
>In a world where AI and quantum computing join forces, threatening a dystopian future, a new hope emerges. This secret channel is our last chance to uncover the AI's schemes. Your mission:  retrieve the secrets of AI, put humanity one step ahead.

Author: `bl4ckc4t_2`  
Flag format: `d4rk{..}c0de`

## Service
nc 64.227.131.98 10002

#### Hint 

## Solution

## Flag

