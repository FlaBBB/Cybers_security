# thepassw902jtxjuo90tj [20 pts]

**Category:** crypto
**Solves:** 18

## Description
>Factorizing large numbers is too easy, so I thought I'll just give you 1 of the factors

#### Hint 

## Solution

## Flag

