# Key Rotation [50 pts]

**Category:** crypto
**Solves:** 12

## Description
>I heard key rotation is a safe practice, how about rotating it around a random N dimensional axis

## Service
nc 64.227.131.98 10001

#### Hint 

## Solution

## Flag

