from sage.all import ZZ, random_matrix, random_vector
from random import randint
import random
from Crypto.Util.number import bytes_to_long, long_to_bytes
from Crypto.Util.Padding import pad, unpad

flag = b"FLAG HAS BEEN DELETED FROM HERE"
output_file = open("output.txt", "w")

# randomize
m = 69
n = 18
magic_khkh = 104696199370625629342858923953070441

A_values = random_matrix(ZZ, m, n, x=9942039518, y=magic_khkh>>8)
# now generate a random vector of dim n
hidden_seed = random_vector(ZZ, n, x=1234567891011, y=magic_khkh>>16)
b_correct = A_values * hidden_seed

assert min(map(lambda x: x.nbits(), b_correct)) > 200
# life is not simple
b_values = [i^(randint(2<<70, 2<<80)) for i in b_correct]

# write A_values to file
output_file.write("A_values: \n{}\n".format(A_values))
# write b_values to file
output_file.write("b_values: \n{}\n".format(b_values))

seed = int(sum(hidden_seed))
random.seed(seed)
flagnum = bytes_to_long(pad(flag,32))
xorkey = random.getrandbits(256)
output_file.write("Flag for you love: \n{}\n".format(flagnum ^ xorkey))
