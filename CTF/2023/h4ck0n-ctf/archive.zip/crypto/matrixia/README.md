# matrixia [490 pts]

**Category:** crypto
**Solves:** 3

## Description
>Do you like Linear Algebra?

#### Hint 

## Solution

## Flag

