# SANITY CHECK [1 pts]

**Category:** sanity
**Solves:** 173

## Description
>Are you sane? The just submit anything inside d4rkc0de{} or d4rk{}c0de

Here's the discord link: https://discord.gg/btAU8B9BWM

#### Hint 

## Solution

## Flag

