import socket

def read_keys_from_file(filename):
    with open(filename, 'r') as file:
        keys = [bytes.fromhex(line.strip()) for line in file.readlines()]
    return keys

def main():
    # Read keys from the file
    keys = read_keys_from_file("key.txt")

    # Get user input for the other party's IP
    other_ip = input("Enter the other party's IP address: ")

    # Create a UDP socket
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    with open("messages.txt", "r") as messages_file:
        for line in messages_file:
            message = line.strip() + ';'

            current_key = keys.pop(0)
            keys.append(current_key)
            while len(current_key) < len(message):
                current_key += current_key

            encrypted_message = encrypt(message.encode(), current_key)

            # Send the encrypted message
            udp_socket.sendto(encrypted_message, (other_ip, 12345))
            print(f"Sent: {message}")

    udp_socket.close()

if __name__ == "__main__":
    main()
