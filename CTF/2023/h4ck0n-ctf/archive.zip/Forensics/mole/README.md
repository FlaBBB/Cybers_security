# mole [300 pts]

**Category:** Forensics
**Solves:** 0

## Description
>ESYA industries were caught in a scandal, and were trying to cover their tracks. But people are the weakest link, someone in the corporation was bought and they bugged the sysadmins system to monitor traffic.

Our forensic team at d4krc0de put together a script to do some stuff but they think its missing something which they cant get a hold of. Can you help our analysts to find the secret they were hiding?

## Service
https://drive.google.com/file/d/1BIiY1qwg0MwmeHw_DdAUYOkwOdKfKdZN/view?usp=drive_link

#### Hint 

## Solution

## Flag

