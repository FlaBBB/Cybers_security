# always painted, never gifted [50 pts]

**Category:** Forensics
**Solves:** 44

## Description
>A GIF masterpiece that my sister was crafting. However, a mischievous hamster named Hamker sneaked in and disrupted the process, altering the GIF's fundamental structure and adding a few extra frames. Remember, the key to success lies in understanding the base of the problem.

## Service
https://drive.google.com/file/d/1AhFLDLlocZqWef3pdkbNkqYkWN-F_FNB/view?usp=sharing

#### Hint 

## Solution

## Flag

