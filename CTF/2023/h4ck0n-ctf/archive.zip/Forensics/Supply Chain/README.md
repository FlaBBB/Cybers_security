# Supply Chain [300 pts]

**Category:** Forensics
**Solves:** 1

## Description
>iPhone >>>>>>>>> Android

## Service
https://drive.google.com/file/d/1bXTehr2f6wWg2WSlAVfEHDUSu9OQs8Nb/view?usp=sharing

#### Hint 

## Solution

## Flag

