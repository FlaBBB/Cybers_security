# comms [45 pts]

**Category:** Forensics
**Solves:** 12

## Description
>Who knew keyboards made packets??

#### Hint 

## Solution

## Flag

