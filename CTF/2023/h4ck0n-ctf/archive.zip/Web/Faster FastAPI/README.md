# Faster FastAPI [150 pts]

**Category:** Web
**Solves:** 81

## Description
>I wanted to get an ECommerce Portal. A dev on Upwork said that he will build it using FastAPI in Python. I have read that Python is very slow, but he assured me that he can make python super fast using some tricks that he know.
Honestly, I don't trust this guy. Can you test the site for any bugs or vulnerabilities? I will pay you for your time by giving you a free access to the admin lounge. Just give me the coupon code for that.

Flag format: `d4rk{..}c0d3` / `d4rk{..}c0de`
both accepted

## Service
http://64.227.131.98:40000/

#### Hint 

## Solution

## Flag

