# Seven Proxies [480 pts]

**Category:** Web
**Solves:** 5

## Description
>My friend said that if we create two APIs and make the public one act as a proxy of other it would be unhackable.
I don't think so. Can you help me out with this?

Here's Z endpoint monsieur

## Service
http://64.227.131.98:40001/

#### Hint 

## Solution

## Flag

