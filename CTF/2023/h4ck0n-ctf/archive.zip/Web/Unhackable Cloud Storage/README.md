# Unhackable Cloud Storage [445 pts]

**Category:** Web
**Solves:** 12

## Description
>There is no way you can read the flag at `/app/flag.txt`

## Service
http://64.227.131.98:40002/

#### Hint 

## Solution

## Flag

