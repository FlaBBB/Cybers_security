# yet another pyjail [230 pts]

**Category:** OSINT  Misc
**Solves:** 15

## Description
>CTFs without jails are boooring, innit?

## Service
nc 64.227.131.98 30000

#### Hint 

## Solution

## Flag

