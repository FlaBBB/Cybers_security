import ast, code, sys
blacklist = "abcdefghijklmnopqrstuvwxyzABCDEFHJKLMNOPQRSTUVWXYZ1234567890" 

entry=r"""
Welcome, enjoy your stay...

     \                  ###########                  /
      \                  #########                  /
       \                                           /
        \                                         /
         \                                       /
          \                                     /
           \                                   /
            \_________________________________/
            |                                 |
            |                                 |
            |                                 |
            |            _________            |
            |           |         |           |
            |           |   ___   |           |
            |           I  |___|  |           |
            |           |         |           |
            |           |         |           |
            |           |        _|           |
            |           |       |#|           |  ;,
    -- ___  |           |         |           |   ;'
    H*/   ` |           |         |      _____|    .,`
    */     )|           I         |     \_____\     ;'
    /___.,';|           |         |     \\     \     ."`
    |     ; |___________|_________|______\\     \      ;:
    | ._,'  /                             \\     \      .
    |,'    /                               \\     \
    ||    /                                 \\_____\
    ||   /                                   \_____|
    ||  /              ___________                \
    || /              / =====o    |                \
    ||/              /  |   /-\   |                 \
    //              /   |         |                  \
   //              /    |   ____  |______             \
  //              /    (O) |    | |      \             \
 //              /         |____| |  0    \             \
//              /          o----  |________\             \
/              /                  |     |  |              \
              /                   |        |               \
             /                    |        |             
            /                     |        |

"""

bye = """
Goodbye.


        _.---,._,'
       /' _.--.<
         /'     `'
       /' _.---._____
       \.'   ___, .-'`
           /'    \\             
         /'       `-.          
        |                       
        |                   .-'~~~`-.
        |                 .'         `.
        |                 |  R  I  P  |
        |                 |           |
        |                 |           |
         \               \\|           |//
   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"""

def console_exit():
    print(bye)
    raise SystemExit

def read_input(args):
    inp = input('>>> ') 
    if len(inp) > 20:
        print("input too long")
        exit()
    if "Attribute" in ast.dump(ast.parse(inp)):
        print("no attribute access allowed")
        exit()
    if "Subscript" in ast.dump(ast.parse(inp)):
        print("no indexing allowed")
        exit()
    for i in blacklist:
        if i in inp:
            print("input contained blaclisted characters")
            exit()
    return inp

while True:
    print(entry)
    try:
        code.interact(banner="", exitmsg=None, local={"exit": console_exit}, readfunc=read_input)
    except SystemExit:
        break
    print(bye)
    break