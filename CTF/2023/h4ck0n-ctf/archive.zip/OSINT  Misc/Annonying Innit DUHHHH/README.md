# Annonying Innit DUHHHH [300 pts]

**Category:** OSINT  Misc
**Solves:** 0

## Description
>Delve into the virtual realm to uncover the enigmatic online identity of "`joeymiller9991`" This intrepid individual, known as Joey Miller, occasionally engages in competitive programming, hailing from the vibrant city of San Francisco, CA. With a penchant for coding and a passion for open source projects, Joey's bio includes, Full-stack Android developer, Open source enthusiast, Coffee lover.

There are 19 components to the flag, but only 10 of them are accurate And there numbering is jumbled up 

Unfortunately, a security lapse led to the compromise of the challenge author's system, yielding a windows dump file.
Hope you'd use it for good purpose.

https://drive.google.com/file/d/1MCheqz0lHUOylY-x8UWu3tkouYQizF01/view?usp=sharing

**Flag Format:**  `d4rk{part6part5part4part2}c0de`.

## Service
nc 64.227.131.98 30001

#### Hint 

## Solution

## Flag

