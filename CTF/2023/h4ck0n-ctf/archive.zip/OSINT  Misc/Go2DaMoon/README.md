# Go2DaMoon [300 pts]

**Category:** OSINT  Misc
**Solves:** 1

## Description
>Elon Scammers hacked our db and promoted doge coin a lot. Doge to the MOOOOOOOOOOON!!!!

## Service
nc 64.227.131.98 30002

#### Hint 

## Solution

## Flag

