# As real world as it gets [290 pts]

**Category:** Reverse Engineering
**Solves:** 3

## Description
>Our agents asked around the blue teamers about any clues on how did the attackers maintained elevated permissions, and they were just as perplexed as we were. So our forensic experts asked them to monitor their usage from which they saw an unusually high amount of  activity of the su binary, could you help our experts with finding out whats wrong in it?

Ps:- Enclose the flag in the flag format `d4rkc0de{}`

#### Hint 

## Solution

## Flag

