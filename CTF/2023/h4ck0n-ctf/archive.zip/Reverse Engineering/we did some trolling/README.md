# we did some trolling [50 pts]

**Category:** Reverse Engineering
**Solves:** 13

## Description
>My teacher taught me some OOPs, so I wanted to get my hands dirty with it.

#### Hint 

## Solution

## Flag

