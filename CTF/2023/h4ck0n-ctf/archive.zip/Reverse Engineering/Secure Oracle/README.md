# Secure Oracle [295 pts]

**Category:** Reverse Engineering
**Solves:** 2

## Description
>Its 21st century, gone are the days when AliBaba shouted Open Sesame, now even AliBaba has a secure channel. How will the 40 thieves know the code now!!??

## Service
nc 64.227.131.98 20000

#### Hint 

## Solution

## Flag

