# Backroom [100 pts]

**Category:** OSINT
**Solves:** 73

## Description
>I found a place that give me a backroom vibes. I think I like this place, so I give this place 5 star. Can you find this place?

[Attachment](https://drive.google.com/file/d/1ppDfAVephnadJlgSa6sdIKwzJqbOw19B/view?usp=sharing)

Author: 0xazr#4883

#### Hint 

## Solution

## Flag

