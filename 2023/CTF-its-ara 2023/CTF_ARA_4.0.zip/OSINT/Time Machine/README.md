# Time Machine [100 pts]

**Category:** OSINT
**Solves:** 82

## Description
>There was a secret leaked on Official ARA Website. It can only seen on January 22nd  2023. Can you turn back the time?

Author: 0xazr#4883

#### Hint 

## Solution

## Flag

