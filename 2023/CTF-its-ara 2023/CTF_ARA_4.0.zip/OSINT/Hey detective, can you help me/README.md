# Hey detective, can you help me [304 pts]

**Category:** OSINT
**Solves:** 36

## Description
>Ada seorang cosplayer dari China yang sangat aktif bersosial media, dia kadang memposting foto cosplaynya di facebook dan instagram.
Dia pernah berkuliah di universitas ternama di China, suatu saat dia dan temannya berkunjung pada toko boneka untuk membeli sebuah boneka, tidak lupa dia juga berfoto dengan sebuah maskot di sana. Lalu selanjutnya dia mampir ke sebuah toko buku untuk membeli buku, sebagai seseorang yang update sosial media dia juga mengambil sebuah foto di toko buku tersebut dengan pose terduduk. Ohh iya dia juga pernah berfoto bareng atau collab dengan cosplayer asal China dengan nama 'Sakura'.

[Attachment](https://drive.google.com/file/d/1LP7xEiZre9QISh9seyhVb4EM-8cesCrJ/view?usp=share_link)

Author: Abdierryy#9836

#### Hint 

## Solution

## Flag

