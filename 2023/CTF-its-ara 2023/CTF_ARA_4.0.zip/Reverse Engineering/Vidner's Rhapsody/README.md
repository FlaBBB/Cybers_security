# Vidner's Rhapsody [304 pts]

**Category:** Reverse Engineering
**Solves:** 36

## Description
>Once I was going to send you the program, but do me a favor by retrieving the real output of the program from this generated JSON program tree. Can you?

[Attachments](https://drive.google.com/file/d/1ULakfSG6zc7cn0BGNWpno3uljrSAhN38/view?usp=sharing)

Author: aseng#2055

#### Hint 

## Solution

## Flag

