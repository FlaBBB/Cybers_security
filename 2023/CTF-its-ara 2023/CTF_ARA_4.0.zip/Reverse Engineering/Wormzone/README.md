# Wormzone [500 pts]

**Category:** Reverse Engineering
**Solves:** 2

## Description
>Done with the warmup from Rhapsody? It's time for the **easier** one ^-^

Facing a lot of PYC's files in Reversing category? 
Looks like it's time we use this kind of tools to protect our python script!

Best and recommended place to run? `Windows 10 x64`

[Attachments](https://drive.google.com/drive/folders/1WLEmSnyCsRVy2jiWCTudsuBrrs3Q9-Qr?usp=share_link)

Author: aseng#2055

#### Hint
* Either runtime analysis or static analysis in easier way requires you a certain tool to dissect the obfuscated python script. Have you checked all of them? There's one could assist you since I don't apply any super protection level enabled tho.
* Do not OVERTHINK by a complicated PyArmor! The flag is processed at **runtime**, you do know you can do something about it and why I suggest you to do it in the Windows right? :)

## Solution

## Flag

