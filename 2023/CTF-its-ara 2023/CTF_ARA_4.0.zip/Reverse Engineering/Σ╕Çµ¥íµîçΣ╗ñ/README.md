# 一条指令 [500 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Not much author wants to spill out their part of the flag in challenge description, but because I'm so kind ...

So here you go, the first correct character of the input program is 'V'

[Attachments](https://drive.google.com/drive/folders/1TDgPVtc_Mh5SnUO4Gm1jTEfPPuMceUPk?usp=share_link)

Author: aseng#2055

#### Hint
* https://www.sciencedirect.com/topics/computer-science/side-channel

## Solution

## Flag

