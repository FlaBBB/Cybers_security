# Thinker [100 pts]

**Category:** Forensic
**Solves:** 61

## Description
>I always overthink about finding other part of myself, can you help me?

[Attachments](https://drive.google.com/file/d/1_kQ5JRhlP2Pa7KQo2-fR1osef1-5KzvF/view)
   
Author: Zangetsu#2398

#### Hint 

## Solution

## Flag

