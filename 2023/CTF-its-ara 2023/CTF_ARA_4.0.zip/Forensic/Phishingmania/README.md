# Phishingmania [500 pts]

**Category:** Forensic
**Solves:** 0

## Description
>Felix has just been phished from a campus PC that he accidentally clicked the downloaded attachment from his email without properly analyzing it. 

He's then taught by a malware analyst and he gave you a job to help Felix gaining an understanding about the malware that has been deployed inside the document's attachment that he clicked before. All the analysis questions are in `questions.txt` and the malicious document can be downloaded from this URL with those questions: https://drive.google.com/drive/folders/13XSpnPCXS8JrqzK4lO5tt1T62BD-83NR?usp=sharing


Download file:
https://drive.google.com/file/d/14ZLCLcFo1ZoHKjSuVvYxwDHy-oDr4Z4e/view?usp=sharing

Password zip: `passwordnyamasbro`

Author: aseng#2055

#### Hint
* What's the difference between emulate and simulate?

## Solution

## Flag

