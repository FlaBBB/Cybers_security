# Leecher [500 pts]

**Category:** Forensic
**Solves:** 0

## Description
>Everyone loves piracy, or so I thought...

[Attachments](https://drive.google.com/file/d/1Gt95u7gwa_7EIBU0vEWVeaYSJSxWAC-V/view?usp=sharing)

Author: fuyuka#0233

#### Hint
* The client I used was pretty popular, so it may have a certain RFC/BEP that could help you understand the protocol mechanism.
* The torrent file was split into 30 pieces, each with a size of 16Kb. You may be able to retrieve the file, If-only-If you can carefully locate the offset of each piece

## Solution

## Flag

