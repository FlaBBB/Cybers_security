# babychall [132 pts]

**Category:** Cryptography
**Solves:** 49

## Description
>Welcome to ARACTF! To start the CTF, please translate this flag that I get from display banner!
[Good Morning](https://www.youtube.com/watch?v=SBrXvqRfb5M)

Format : ARA2023{lowercase_flag}

[Attachments](https://drive.google.com/file/d/1GWeLn4Ek7MnTgLtZiJnP3FVV6c2XVRQZ/view?usp=share_link)

Author: circlebytes#5520

#### Hint 

## Solution

## Flag

