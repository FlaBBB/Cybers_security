# Secrets Behind a Letter [100 pts]

**Category:** Cryptography
**Solves:** 67

## Description
>Melon and Edith went to an labyrinth and they should break the code written on a letter in a box in order to escape the labyrinth. 

Open the letter and break the code

[Attachments](https://drive.google.com/file/d/1qKvtN-4Jx8-E3udpYRA4tUs_pW7yt59q/view?usp=sharing)

Author: L e n s#1048

#### Hint 

## Solution

## Flag

