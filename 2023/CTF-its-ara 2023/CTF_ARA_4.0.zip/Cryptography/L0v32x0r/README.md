# L0v32x0r [100 pts]

**Category:** Cryptography
**Solves:** 59

## Description
>Vonny and Zee were having a treasure hunt game until they realized that one of the clues was a not alike the other clues as it has a random text written on the clue.

The clue was "001300737173723a70321e3971331e352975351e247574387e3c".

Help them to find what the hidden clue means!

Author: L e n s#1048

#### Hint 

## Solution

## Flag

