# SH4-32 [100 pts]

**Category:** Cryptography
**Solves:** 55

## Description
>Sze received an ecnrypted file and a message containing the clue of the file password from her friend. 

The clue was a hash value : 9be9f4182c157b8d77f97d3b20f68ed6b8533175831837c761e759c44f6feeb8

Decrypt the file password!

[Attachments](https://drive.google.com/file/d/1muNug7KzmiHwjx3GCvhrWJzi_tGOugaK/view?usp=sharing)

Author: L e n s#1048

#### Hint 

## Solution

## Flag

