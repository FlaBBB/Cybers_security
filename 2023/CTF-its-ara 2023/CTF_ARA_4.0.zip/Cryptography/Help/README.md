# Help [443 pts]

**Category:** Cryptography
**Solves:** 18

## Description
>Bob is receiving a message from their clients, to put this text on the display in the office. Bob is confused because he didn't know what it is, can you help him?

Format: ARA2023{lowercase_flag}

[Attachments](https://drive.google.com/file/d/1M2EGUtH0cgqlEUgGoyFaTNMCEaCvaFVC/view?usp=share_link)

Author: circlebytes#5520

#### Hint 

## Solution

## Flag

