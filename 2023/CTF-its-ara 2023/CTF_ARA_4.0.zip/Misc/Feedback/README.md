# Feedback [50 pts]

**Category:** Misc
**Solves:** 42

## Description
>Wah, gimana pelaksanaan lomba CTFnya? Soalnya sulit atau mudah nih? 

Nah setelah selesai mengerjakan soal CTFnya, temen-temen bisa isi feedback terlebih dahulu dan feedback ini diisi oleh masing-masing peserta yaa!😁

https://intip.in/FeedbackCTFARA4

Terima kasih banyak sudah membantu kami untuk menjadi lebih baik dan sampai jumpa di serangkaian kegiatan ARA selanjutnya!!✨

#### Hint 

## Solution

## Flag

