# @B4SH [100 pts]

**Category:** Misc
**Solves:** 80

## Description
>Ailee had just moved out to a boarding house in the countryside to escape the fast-paced and hectic city life. She was very excited to start her life with a new environment, she was very happy before she found out that the room she rented was very dark. Suddenly she found out 2 strange papers on the wall behind the door that says: 

"5A495A323032337B346D62793077625F677330663973675F677334675F2167355F345F733468733F7D". 

Help Ailee to find what's behind the text written on the paper.

Author: L e n s#1048

#### Hint 

## Solution

## Flag

