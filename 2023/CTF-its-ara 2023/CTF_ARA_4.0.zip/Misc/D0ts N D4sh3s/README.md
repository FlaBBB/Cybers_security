# D0ts N D4sh3s [100 pts]

**Category:** Misc
**Solves:** 87

## Description
>Albert was lost in a deep forest surrounded by a sea and tried to escape by sending a SOS signal containing a code.

Jack who works at a lighthouse realized that someone was sending a SOS signal and responses as fast as he can.

What do you think Albert tries to say?

Chall File : https://drive.google.com/file/d/1h5ht0z64ChQ3v28o9Uq-GI0Uk21camH2/view?usp=sharing

Author: L e n s#1048

#### Hint 

## Solution

## Flag

