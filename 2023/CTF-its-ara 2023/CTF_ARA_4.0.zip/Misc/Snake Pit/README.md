# Snake Pit [500 pts]

**Category:** Misc
**Solves:** 1

## Description
>Back then, I stumbled upon a snake pit. It was a dark place filled with traps, making it difficult to find a way out.

[Attachments](https://drive.google.com/file/d/1vuawCInpdkx9gB7_mWK33UnvQxvCL_YO/view?usp=sharing)

`nc 103.152.242.116 9054`

Author: fuyuka#0233

#### Hint
* I heard that you can overcome these trials by mastering the depth of snake `magic` yourself.
* You may consider overriding the `Enum class`'s method in your jailbreak attempt

## Solution

## Flag

