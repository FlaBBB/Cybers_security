# Truth [176 pts]

**Category:** Misc
**Solves:** 45

## Description
>Kuronushi traveled far away from his country to learn something about himself. He never sure about his identity.  Untill One day, he met a sage who gave him a book of truth. The sage said " To understand about yourself,Erase the title and find the Bigger case"

Submit the flag on this format ARA2023{}
Separate the sentences with _

[Attachments](https://drive.google.com/file/d/1nwDlCdpraSrd5FuocZnkVR6_L9HcvuUu/view)

Author: Zangetsu#2398

#### Hint 

## Solution

## Flag

