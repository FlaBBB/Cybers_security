# in-sanity check [100 pts]

**Category:** Misc
**Solves:** 75

## Description
>Even the flag for sanity check is gone?

[Attachments](https://docs.google.com/document/d/1Jq0AehMiC8Bjkd_Bl7rADQvk6u4ZS8vgFQxIO0SDmi0/edit)

Author: circlebytes#5520

#### Hint 

## Solution

## Flag

